"""OmniPhyto compound intake and ligand-preparation workspace.

Only user-supplied compounds and verified artifacts are displayed. This is a
research workflow prototype, not a clinical tool; docking and scoring are not
run by this dashboard.
"""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path

import pandas as pd
import streamlit as st

from omniphyto.input_preview import validate_compound_csv
from omniphyto.ligand_prep import dependency_status
from omniphyto.pipeline import run_pipeline
from omniphyto.results import load_validated_preparations
from omniphyto.settings import FIELDS, load_settings, save_settings, validate_settings

ROOT = Path(__file__).resolve().parent
INPUT_PATH = ROOT / "data" / "input" / "compounds.csv"
OUTPUT_DIR = ROOT / "data" / "output"
SETTINGS_PATH = ROOT / "data" / "input" / "project_settings.json"
COLUMN_MAP_PATH = ROOT / "data" / "input" / "compound_columns.json"
MANIFEST = OUTPUT_DIR / "manifest.csv"
PAGES = ["Overview", "Upload compounds", "Run Pipeline", "Ligand prep", "Results", "Settings"]


def saved_column_map() -> dict[str, str]:
    try:
        data = json.loads(COLUMN_MAP_PATH.read_text(encoding="utf-8"))
        return {"id_column": str(data["id_column"]), "smiles_column": str(data["smiles_column"])}
    except (OSError, ValueError, KeyError, TypeError):
        return {"id_column": "compound_id", "smiles_column": "smiles"}


def inject_styles() -> None:
    st.markdown("""<style>
    :root { color-scheme: dark; }
    .stApp { background: radial-gradient(ellipse at 78% 0%, #162b38 0, #0b1420 43%, #08111a 100%); color: #e8f0ef; }
    [data-testid="stHeader"] { background: rgba(8,17,26,.78); }
    [data-testid="stToolbar"] { right: 1rem; }
    .block-container { max-width: 1420px; padding-top: 1.7rem; padding-bottom: 3rem; }
    [data-testid="stSidebar"] { background: linear-gradient(180deg,#101d29,#0c1721 82%); border-right: 1px solid #243846; }
    [data-testid="stSidebar"] > div:first-child { padding-top: 1.5rem; }
    [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p { color: #9db2b5; }
    [data-testid="stSidebar"] [role="radiogroup"] { gap: .3rem; }
    [data-testid="stSidebar"] [role="radio"] { padding: .3rem .45rem; border-radius: 9px; }
    h1,h2,h3 { color:#f1f6f3 !important; letter-spacing:-.025em; }
    [data-testid="stMetric"] { background:transparent; }
    [data-testid="stMetricValue"] { color:#f2f7f3; }
    [data-testid="stMetricLabel"] { color:#9db2b5; }
    [data-testid="stVerticalBlock"] > [data-testid="stHorizontalBlock"] { gap: 1rem; }
    div[data-testid="stForm"] { background:#101e2b; border:1px solid #263a49; border-radius:16px; padding:1.1rem 1.25rem; }
    div[data-testid="stFileUploader"] { background:#101e2b; border:1px dashed #426052; border-radius:14px; padding:.65rem; }
    .brand { display:flex; align-items:center; gap:12px; padding:6px 6px 2px; }
    .brand-icon { width:44px;height:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;background:linear-gradient(145deg,#1b6a4d,#163a37);border:1px solid #2c8e67;font-size:24px;box-shadow:0 0 26px #16c77a26; }
    .brand-name { color:#f4fbf7;font-size:24px;line-height:1.05;font-weight:800;letter-spacing:-.7px; }.brand-tag { color:#8998a7;font-size:11px;margin-top:4px;letter-spacing:0;text-transform:none; }
    .eyebrow { color:#79d9ab;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:1.8px; }
    .welcome-title { font-size:31px;letter-spacing:-1px;font-weight:800;color:#f3f7fb;margin:0; }.welcome-sub { font-size:13px;color:#96a4b3;margin-top:3px; }.online-pill { display:inline-flex;align-items:center;gap:8px;border:1px solid #287a55;border-radius:30px;padding:8px 12px;background:#10271d;color:#a7edc5;font-size:10px;font-weight:700;white-space:nowrap; }.online-dot { width:8px;height:8px;background:#39dc8d;border-radius:50%;box-shadow:0 0 10px #39dc8d; }
    .panel { min-height:unset;padding:16px 17px;border:1px solid #243142;border-radius:13px;background:linear-gradient(145deg,#111a27,#0e1621);box-shadow:0 10px 28px rgba(0,0,0,.12); }.panel-title { color:#edf3f8;font-size:15px;font-weight:800;margin:0 0 7px; }.panel-kicker { color:#82a096;font-size:10px;font-weight:700;letter-spacing:.13em;text-transform:uppercase;margin-bottom:6px; }.panel-copy { color:#97aaad;font-size:12px;line-height:1.55;margin:0; }.panel-sub { font-size:9px;color:#8290a0;margin-bottom:14px; }
    .metric-card { height:112px;border-radius:13px;padding:15px 17px;background:linear-gradient(135deg,#121e2b,#101722);border:1px solid #283648;position:relative;overflow:hidden; }
    .metric-card:after { content:'';position:absolute;right:-28px;top:-40px;width:110px;height:110px;border-radius:50%;background:var(--glow);filter:blur(34px);opacity:.18; }
    .metric-card.green { --accent:#35dc91;--glow:#35dc91; }.metric-card.blue { --accent:#53b5ff;--glow:#53b5ff; }.metric-card.purple { --accent:#b18aff;--glow:#b18aff; }.metric-card.amber { --accent:#ffc05b;--glow:#ffc05b; }
    .metric-label { color:#aab6c3;font-size:10px;font-weight:700;position:relative;z-index:1; }.metric-row { display:flex;justify-content:space-between;align-items:end;margin-top:14px;position:relative;z-index:1; }.metric-value { color:#f1f6fa;font-size:27px;font-weight:800;letter-spacing:-.8px;line-height:1; }.metric-note { color:#8593a2;font-size:9px;margin-top:7px;position:relative;z-index:1; }.metric-icon { font-size:23px;color:var(--accent);position:absolute;right:16px;top:43px; }
    .status-banner { background:linear-gradient(90deg,#15352b,#10221e);border:1px solid #287a55;border-left:4px solid #39dc8d;color:#b6efcf;border-radius:11px;padding:11px 15px;margin:8px 0 18px;font-size:11px;font-weight:700; }
    .step { display:grid;grid-template-columns:27px 1fr auto;gap:10px;align-items:center;min-height:51px;position:relative; }.step:not(:last-child):after { content:'';position:absolute;left:12px;top:31px;height:26px;width:2px;background:#294937; }.step-node { width:25px;height:25px;border-radius:50%;border:1px solid #3a4a5c;background:#151e2a;color:#8191a2;font-size:11px;font-weight:800;display:flex;align-items:center;justify-content:center;z-index:1; }.step.done .step-node { background:#153c2d;border-color:#27a86b;color:#59efa6; }.step-name { font-size:10px;color:#e5edf5;font-weight:700; }.step-desc { font-size:9px;color:#8593a1;margin-top:2px; }.step-status { font-size:9px;font-weight:700;white-space:nowrap;color:#48db91; }.step.pending .step-status { color:#788594; }
    .viewer-box { height:260px;border-radius:10px;background:radial-gradient(ellipse at 52% 50%,#122b42 0,#0b1420 53%,#070c13 100%);border:1px solid #26384b;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden; }.viewer-box:before { content:'';position:absolute;width:270px;height:190px;border:1px solid #244d70;border-radius:50%;transform:rotate(-26deg);box-shadow:0 0 55px #1e81d12c,inset 0 0 35px #1e81d11a; }.viewer-empty { position:relative;text-align:center;color:#8092a5;font-size:11px;line-height:1.6;max-width:280px;z-index:1; }.viewer-glyph { font-size:48px;color:#5a7e8d;opacity:.62;line-height:1.2;margin-bottom:8px; }.viewer-label { position:absolute;left:12px;bottom:10px;color:#8092a5;background:#101a26;border:1px solid #344252;border-radius:6px;padding:5px 8px;font-size:9px;font-weight:700;z-index:2; }
    .insight { padding:8px 0;border-bottom:1px solid #202a37;color:#c2ccd6;font-size:10px;line-height:1.45; }.insight:last-child { border-bottom:0; }.insight b { color:#eff4f8; }.insight-icon { display:inline-block;width:22px;font-size:13px; }.bottom-note { color:#788796;font-size:9px;margin-top:12px;line-height:1.45; }
    .nav-label { margin:22px 8px 7px;color:#657487;font-size:10px;font-weight:800;letter-spacing:1.6px; }.sidebar-foot { margin-top:24vh;padding:15px 8px;color:#6f947e;font-size:11px;text-align:center;border-top:1px solid #1b2b2c; }
    [data-testid="stSidebar"] [data-testid="stRadio"] div[role="radiogroup"] { gap:5px; }.stRadio label { border-radius:9px;color:#aab7c5; }.stRadio label:has(input:checked) { color:#b5f5d5; }
    .panel-empty { min-height:94px;display:flex;flex-direction:column;justify-content:center;gap:7px;color:#d9e4eb;font-size:12px;font-weight:700; }.panel-empty span { color:#8798a9;font-size:10px;font-weight:400;line-height:1.5; }
    .demo-banner { background:linear-gradient(90deg,#3a2110,#241718);border:1px solid #bc722a;border-left:5px solid #ffb64d;color:#ffe0b0;border-radius:11px;padding:13px 16px;margin:8px 0 18px;font-size:12px;font-weight:900;letter-spacing:.06em; }.demo-card-tag { color:#ffc56d;font-size:8px;font-weight:900;letter-spacing:.15em;margin-top:5px; }.demo-section { color:#8ee5bb;font-size:10px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;margin:8px 0 10px; }
    [data-testid="stDataEditor"] { border:1px solid #29394a;border-radius:10px;overflow:hidden; }.stSlider [data-baseweb="slider"] { margin-top:3px; }
    </style>""", unsafe_allow_html=True)


def panel(title: str, copy: str, kicker: str = "") -> None:
    st.markdown(f'<div class="panel">{f"<div class=panel-kicker>{kicker}</div>" if kicker else ""}<div class="panel-title">{title}</div><p class="panel-copy">{copy}</p></div>', unsafe_allow_html=True)


def metric_card(label: str, value: int | str, note: str, icon: str, color: str, demo: bool = False) -> None:
    tag = '<div class="demo-card-tag">DEMO ONLY</div>' if demo else ""
    st.markdown(f'<div class="metric-card {color}"><div class="metric-label">{label}</div><div class="metric-row"><div class="metric-value">{value}</div></div><div class="metric-icon">{icon}</div><div class="metric-note">{note}</div>{tag}</div>', unsafe_allow_html=True)


def render_stage(number: int, name: str, desc: str, status: str, done: bool = False) -> None:
    state = "done" if done else "pending"
    st.markdown(f'<div class="step {state}"><div class="step-node">{"✓" if done else number}</div><div><div class="step-name">{name}</div><div class="step-desc">{desc}</div></div><div class="step-status">{status}</div></div>', unsafe_allow_html=True)


def overview_data():
    input_count = 0
    input_ok = False
    input_error = ""
    if INPUT_PATH.is_file():
        mapping = saved_column_map()
        try:
            _, rows = validate_compound_csv(
                INPUT_PATH.read_bytes(), id_column=mapping["id_column"], smiles_column=mapping["smiles_column"]
            )
            input_count, input_ok = len(rows), True
        except ValueError as exc:
            input_error = str(exc)
    try:
        verified_rows, manifest_rows = load_validated_preparations(OUTPUT_DIR)
    except (OSError, ValueError, csv.Error):
        verified_rows, manifest_rows = [], []
    prepared_count = len(verified_rows)
    failed_count = sum(1 for row in manifest_rows if row.get("ligand_status", "").lower() == "failed")
    return input_count, input_ok, input_error, verified_rows, manifest_rows, prepared_count, failed_count


_mapping = saved_column_map()
st.set_page_config(page_title="OmniPhyto | Research workspace", page_icon="🌿", layout="wide")
st.session_state.setdefault("id_column", _mapping["id_column"])
st.session_state.setdefault("smiles_column", _mapping["smiles_column"])
inject_styles()

with st.sidebar:
    st.markdown('<div class="brand"><div class="brand-icon">🌿</div><div><div class="brand-name">OmniPhyto</div><div class="brand-tag">Natural Products for Drug Discovery</div></div></div>', unsafe_allow_html=True)
    st.markdown('<div class="nav-label">WORKSPACE</div>', unsafe_allow_html=True)
    page = st.radio("Workspace navigation", PAGES, label_visibility="collapsed", key="nav")
    st.markdown('<div class="sidebar-foot">DISCOVER · PREPARE · VERIFY<br><br>Research prototype · no clinical claims</div>', unsafe_allow_html=True)

settings = load_settings(SETTINGS_PATH)
input_count, input_ok, input_error, prepared_rows, manifest_rows, prepared_count, failed_count = overview_data()


def page_header(title: str, subtitle: str, eyebrow: str = "NATURAL PRODUCTS · DISCOVERY WORKSPACE") -> None:
    head_l, head_r = st.columns([5, 2], vertical_alignment="center")
    with head_l:
        st.markdown(f'<div class="eyebrow">{eyebrow}</div><p class="welcome-title">{title}</p><div class="welcome-sub">{subtitle}</div>', unsafe_allow_html=True)
    with head_r:
        project = settings.get("project_name", "").strip()
        label = project if project else "PROJECT NOT CONFIGURED"
        st.markdown(f'<div style="text-align:right"><span class="online-pill"><span class="online-dot"></span>{"INPUT VALIDATED" if input_ok else "WAITING FOR REAL DATA"}</span><br><div style="margin-top:10px;color:#bdc9d4;font-size:11px">{label}</div></div>', unsafe_allow_html=True)
    st.markdown(f'<div class="status-banner">{ "Real input and verified artifacts only" if input_ok or prepared_rows else "No project compounds or preparation outputs are loaded. Upload real input to begin."} · no demo data, fabricated scores, or unrun scientific results</div>', unsafe_allow_html=True)


def dashboard_header(demo: bool = False) -> None:
    head_l, head_r = st.columns([5, 2], vertical_alignment="center")
    with head_l:
        st.markdown('<div class="eyebrow">NATURAL PRODUCTS · DISCOVERY WORKSPACE</div><p class="welcome-title">⚗️ Welcome to OmniPhyto</p><div class="welcome-sub">A transparent workspace for compound intake and ligand preparation</div>', unsafe_allow_html=True)
    with head_r:
        project = settings.get("project_name", "").strip() or "PROJECT NOT CONFIGURED"
        label = project if project else "PROJECT NOT CONFIGURED"
        if demo:
            st.markdown('<div style="text-align:right"><span class="online-pill" style="border-color:#bc722a;background:#2e2117;color:#ffe0b0"><span class="online-dot" style="background:#ffb64d;box-shadow:0 0 10px #ffb64d"></span>DEMO MODE</span></div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div style="text-align:right"><span class="online-pill"><span class="online-dot"></span>{"INPUT VALIDATED" if input_ok else "WAITING FOR REAL DATA"}</span><br><div style="margin-top:10px;color:#bdc9d4;font-size:11px">{label}</div></div>', unsafe_allow_html=True)
    if demo:
        st.markdown('<div class="demo-banner">⚠ DEMO DATA ONLY · FICTIONAL UI PLACEHOLDERS · NOT REAL COMPOUNDS, SCIENTIFIC RESULTS, OR HOSPITAL EVIDENCE</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="status-banner">{"Real uploaded compounds and verified preparation files only" if input_ok or prepared_rows else "No compound records or preparation outputs yet. Empty-state dashboard is ready for real inputs."} · no demo rows, fake scores, or fabricated rankings</div>', unsafe_allow_html=True)


if page == "Overview":
    demo_mode = st.sidebar.toggle("DEMO dashboard (fictional UI only)", value=False, help="Shows clearly tagged fictional layout content only. It never feeds the pipeline or live results.", key="demo_mode")
    dashboard_header(demo=demo_mode)
    if demo_mode:
        demo_defaults = {"records": 1250, "prepared": 820, "candidates": 120, "insights": 28, "admin_filter": 20}
        if "demo_metrics" not in st.session_state:
            st.session_state["demo_metrics"] = demo_defaults.copy()
        metrics = st.session_state["demo_metrics"]
        with st.expander("Edit demo dashboard model", expanded=False):
            st.caption("Fictional layout values only. Saved in this browser session. These values never enter input files, pipeline, or real results.")
            edit_cols = st.columns(4)
            for col, (key, label) in zip(edit_cols, [("records", "Loaded-record card"), ("prepared", "Prepared-count card"), ("candidates", "Candidate card"), ("insights", "Insight card")]):
                metrics[key] = col.number_input(label, min_value=0, max_value=999999, value=int(metrics[key]), step=1, key=f"edit_demo_{key}")
            metrics["admin_filter"] = st.number_input("Admin filter display", min_value=1, max_value=9999, value=int(metrics["admin_filter"]), step=1, key="edit_demo_admin_filter")
            st.caption("Admin filter is a demo control label, not a permission/security feature.")
        metric_cols = st.columns(4)
        labels = [("COMPOUNDS LOADED", metrics["records"], "DEMO record count", "🌿", "green"), ("PREPARED LIGANDS", metrics["prepared"], "DEMO prep count", "⌬", "blue"), ("CANDIDATES", metrics["candidates"], "DEMO candidate count", "◈", "purple"), ("KEY INSIGHTS", metrics["insights"], "DEMO insight count", "✦", "amber")]
        for col, args in zip(metric_cols, labels):
            with col:
                metric_card(*args, demo=True)
        st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)
        left, right = st.columns([1.02, 1.15], gap="medium")
        with left:
            progress_options = ["Not started", "In progress", "Complete", "Blocked"]
            st.markdown('<div class="panel"><div class="panel-title">▥ &nbsp;Pipeline Progress <span class="demo-card-tag">DEMO</span></div><div class="panel-sub">Editable illustrative workflow states only</div>', unsafe_allow_html=True)
            for stage, default in [("Compound intake", "Complete"), ("Ligand preparation", "In progress"), ("Docking", "Not started")]:
                state = st.selectbox(f"{stage} status", progress_options, index=progress_options.index(default), key=f"demo_stage_{stage}")
                st.markdown(f'<div class="step pending"><div class="step-node">◌</div><div><div class="step-name">{stage}</div><div class="step-desc">Illustrative status, not connected to a scientific run</div></div><div class="step-status">{state}</div></div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
        with right:
            st.markdown('<div class="panel"><div class="panel-title">⬡ &nbsp;Molecular View <span class="demo-card-tag">DEMO PLACEHOLDER</span></div><div class="panel-sub">Decorative graphic only. No molecule is rendered.</div><div class="viewer-box"><div class="viewer-empty"><div class="viewer-glyph">⌬</div>molecule preview placeholder<br>This is not a chemical structure</div><div class="viewer-label">DEMO ONLY</div></div></div>', unsafe_allow_html=True)
        st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)
        left, right = st.columns([1.2, .85], gap="medium")
        with left:
            st.markdown('<div class="panel"><div class="panel-title">◈ &nbsp;Top-ranked candidates <span class="demo-card-tag">DEMO DATA</span></div><div class="panel-sub">Fictional sample rows, not real compounds or rankings</div>', unsafe_allow_html=True)
            initial = pd.DataFrame([{"candidate": "DEMO compound A", "demo_score": 9.4, "demo_status": "Illustrative"}, {"candidate": "DEMO compound B", "demo_score": 8.1, "demo_status": "Illustrative"}, {"candidate": "DEMO compound C", "demo_score": 7.6, "demo_status": "Illustrative"}])
            demo_rows = st.data_editor(initial, num_rows="dynamic", use_container_width=True, hide_index=True, key="demo_candidates", column_config={"candidate": st.column_config.TextColumn("Candidate (DEMO)", required=True), "demo_score": st.column_config.NumberColumn("Demo display value", help="Not a measured or predicted score"), "demo_status": st.column_config.TextColumn("Status (DEMO)")})
            st.markdown('<div class="bottom-note">Rows are editable placeholders; they are isolated from live data and cannot be exported as results.</div></div>', unsafe_allow_html=True)
        with right:
            st.markdown('<div class="panel"><div class="panel-title">✦ &nbsp;Key Insights <span class="demo-card-tag">DEMO</span></div><div class="panel-sub">Editable display-only notes</div>', unsafe_allow_html=True)
            demo_insights = st.text_area("Demo insight text", value="Illustrative dashboard insight.\nNo scientific inference is being made.", height=105, key="demo_insight_text", label_visibility="collapsed")
            st.markdown(f'<div class="insight"><span class="insight-icon">✦</span>{demo_insights.replace(chr(10), "<br>")}</div><div class="insight"><span class="insight-icon">◉</span>Admin filter: <b>{int(metrics["admin_filter"])}</b> items (DEMO control)</div><div class="bottom-note">All displayed demo counts, rows and notes are fictional UI placeholders.</div></div>', unsafe_allow_html=True)
        st.caption("Research workflow prototype. Demo mode is visual only and not validated for hospital or clinical use.")
    else:
        metric_cols = st.columns(4)
        with metric_cols[0]:
            metric_card("COMPOUNDS LOADED", input_count, "Validated uploaded records", "🌿", "green")
        with metric_cols[1]:
            metric_card("PREPARED LIGANDS", prepared_count, "Verified prep artifacts", "⌬", "blue")
        with metric_cols[2]:
            metric_card("PREP FAILURES", failed_count, "Recorded real errors", "!", "amber")
        with metric_cols[3]:
            metric_card("DOCKING SCORES", "NOT RUN", "Not implemented here", "—", "purple")
        st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)
        left, right = st.columns([1.02, 1.15], gap="medium")
        with left:
            stages = "".join(
                f'<div class="step {"done" if done else "pending"}"><div class="step-node">{"✓" if done else number}</div><div><div class="step-name">{name}</div><div class="step-desc">{desc}</div></div><div class="step-status">{status}</div></div>'
                for number, name, desc, status, done in [
                    (1, "Compound intake", "Schema validation only, not chemistry validation", "Complete" if input_ok else "Waiting", input_ok),
                    (2, "Ligand preparation", "Actual implemented prep only", f"{prepared_count} prepared" if prepared_count else "Not run", bool(prepared_count)),
                    (3, "Docking and scoring", "Not executed or reported by this app", "Not run", False),
                ]
            )
            st.markdown(f'<div class="panel"><div class="panel-title">▥ &nbsp;Pipeline Progress</div><div class="panel-sub">Live state from validated inputs and verified outputs</div>{stages}</div>', unsafe_allow_html=True)
        with right:
            molecule_copy = "Verified ligand files exist. Use Ligand prep to inspect per-compound records." if prepared_rows else "No molecular structure loaded<br>Upload real compounds and complete ligand preparation to create verified structure files."
            molecule_label = "PREPARATION OUTPUTS VERIFIED" if prepared_rows else "NO STRUCTURE DATA"
            st.markdown(f'<div class="panel"><div class="panel-title">⬡ &nbsp;Molecular View</div><div class="panel-sub">Only a verified structure file can be shown</div><div class="viewer-box"><div class="viewer-empty"><div class="viewer-glyph">⌬</div>{molecule_copy}</div><div class="viewer-label">{molecule_label}</div></div></div>', unsafe_allow_html=True)
        st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)
        left, right = st.columns([1.2, .85], gap="medium")
        with left:
            st.markdown('<div class="panel"><div class="panel-title">◈ &nbsp;Candidates and Results</div><div class="panel-sub">Real input records and verified preparation status, never a fabricated ranking</div>', unsafe_allow_html=True)
            if manifest_rows:
                st.dataframe(pd.DataFrame(manifest_rows).fillna(""), hide_index=True, use_container_width=True)
            elif input_ok:
                st.dataframe(pd.read_csv(INPUT_PATH).fillna(""), hide_index=True, use_container_width=True)
            else:
                st.markdown('<div class="panel-empty">No candidates to show yet<br><span>Upload a real compounds CSV. This panel will use only those records and any later verified preparation output.</span></div>', unsafe_allow_html=True)
            st.markdown('<div class="bottom-note">No candidate is ranked. Docking, binding scores, efficacy, ADMET, toxicity, and safety are not reported.</div></div>', unsafe_allow_html=True)
        with right:
            insights = f'<div class="insight"><span class="insight-icon">▤</span>Schema-valid compound records: <b>{input_count}</b></div><div class="insight"><span class="insight-icon">⌬</span>Verified ligand preparations: <b>{prepared_count}</b></div><div class="insight"><span class="insight-icon">!</span>Recorded prep failures: <b>{failed_count}</b></div><div class="insight"><span class="insight-icon">◉</span>Docking and scoring: <b>not run</b></div>'
            st.markdown(f'<div class="panel"><div class="panel-title">✦ &nbsp;Project Insights</div><div class="panel-sub">Derived from current input and output files only</div>{insights}<div class="bottom-note">Counts are based only on uploaded records and verified manifest artifacts.</div></div>', unsafe_allow_html=True)
        st.caption("Research workflow prototype. Not validated for hospital or clinical use.")

elif page == "Upload compounds":
    page_header("Upload compounds", "Bring in a real CSV and check its schema before saving.", "OMNIPHYTO / DATA INTAKE")
    panel("Accepted input", "UTF-8 CSV with one unique compound ID column and one SMILES column. Table validation does not prove chemical validity; RDKit checks structures during preparation.", "SCHEMA")
    uploaded = st.file_uploader("Compound CSV", type=["csv"], key="compound_csv")
    if uploaded:
        raw = uploaded.getvalue()
        try:
            decoded = raw.decode("utf-8-sig")
            headers = next(csv.reader(io.StringIO(decoded)))
            if not headers:
                raise ValueError("CSV must include a header row")
            if MANIFEST.is_file():
                st.warning("A prior pipeline manifest exists. Saving new compounds will not replace its records. Archive the old output before running again.")
            c1, c2 = st.columns(2)
            prior_id = st.session_state.get("id_column", _mapping["id_column"])
            prior_smiles = st.session_state.get("smiles_column", _mapping["smiles_column"])
            id_default = headers.index(prior_id) if prior_id in headers else (headers.index("compound_id") if "compound_id" in headers else 0)
            smiles_default = headers.index(prior_smiles) if prior_smiles in headers else (headers.index("smiles") if "smiles" in headers else min(1, len(headers)-1))
            selected_id = c1.selectbox("Compound ID column", headers, index=id_default, key="choose_id_column")
            selected_smiles = c2.selectbox("SMILES column", headers, index=smiles_default, key="choose_smiles_column")
            _, rows = validate_compound_csv(raw, id_column=selected_id, smiles_column=selected_smiles)
            st.success(f"CSV schema valid: {len(rows)} compound rows. Molecular validity is checked during preparation.")
            st.dataframe(pd.DataFrame(rows[:20]), hide_index=True, use_container_width=True)
            if st.button("Save validated compounds", type="primary"):
                INPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
                INPUT_PATH.write_bytes(raw)
                COLUMN_MAP_PATH.write_text(json.dumps({"id_column": selected_id, "smiles_column": selected_smiles}, indent=2), encoding="utf-8")
                st.session_state["id_column"], st.session_state["smiles_column"] = selected_id, selected_smiles
                st.success(f"Saved input to {INPUT_PATH.relative_to(ROOT)}")
        except (ValueError, UnicodeDecodeError, StopIteration, csv.Error) as exc:
            st.error(f"CSV not accepted: {exc}")
    else:
        st.info("No file selected. Nothing has been saved or inferred.")

elif page == "Run Pipeline":
    page_header("Run pipeline", "One safe action, limited to actual ligand preparation.", "OMNIPHYTO / EXECUTION")
    panel("What this run does", "Reads the saved compound CSV and attempts real 3D ligand preparation. Docking and scoring are not invoked by this dashboard, even when receptor and box settings are filled.", "IMPLEMENTED STEP")
    tool_status = dependency_status()
    missing_tools = [name for name, available in tool_status.items() if not available]
    if not INPUT_PATH.is_file():
        st.error("Pipeline blocked: upload and save a real compound CSV first.")
    else:
        mapping = saved_column_map()
        try:
            _, compounds = validate_compound_csv(INPUT_PATH.read_bytes(), id_column=mapping["id_column"], smiles_column=mapping["smiles_column"])
            st.write(f"Validated input: **{len(compounds)}** compound records")
            if missing_tools:
                st.error("Pipeline blocked. Missing ligand-preparation tools: " + ", ".join(missing_tools) + ". No output was created.")
            elif st.button("Run ligand preparation", type="primary"):
                try:
                    succeeded, total = run_pipeline(INPUT_PATH, OUTPUT_DIR, id_column=mapping["id_column"], smiles_column=mapping["smiles_column"], seed=2026, overwrite=False)
                    st.success(f"Ligand preparation finished: {succeeded}/{total} compounds prepared. See Ligand prep for per-compound status and errors.")
                    st.warning("Docking and scoring were not run. No ranking or binding score is available from this action.")
                except Exception as exc:
                    st.error(f"Pipeline stopped safely: {exc}")
        except ValueError as exc:
            st.error(f"Pipeline blocked by CSV validation: {exc}")
    st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)
    blockers = [f"{name} is missing" for name, available in tool_status.items() if not available]
    if not INPUT_PATH.is_file():
        blockers.insert(0, "real compound CSV not uploaded")
    if blockers:
        st.info("Current preparation blockers: " + "; ".join(blockers) + ".")
    st.caption("Receptor PDBQT, target-specific box coordinates, and an approved docking protocol are not used because docking/scoring is not implemented in this dashboard.")

elif page == "Ligand prep":
    page_header("Ligand preparation", "Inspect per-compound outcomes from real inputs and recorded runs.", "OMNIPHYTO / PREPARATION")
    panel("Preparation record", "Each row reflects an actual input record and its recorded status or error. Prepared files are counted only when the manifest points to a non-empty artifact inside the output folder.", "VERIFICATION RULE")
    if not INPUT_PATH.is_file():
        st.info("No saved compound CSV. Upload and save real compounds first.")
    else:
        status = dependency_status()
        st.write("Tool availability: " + " · ".join(f"{name}: {'available' if available else 'missing'}" for name, available in status.items()))
        if manifest_rows:
            st.dataframe(pd.DataFrame(manifest_rows).fillna(""), hide_index=True, use_container_width=True)
            st.caption(f"Verified prepared files: {prepared_count}. Manifest rows also show real failures and errors.")
        else:
            st.info("No preparation manifest is recorded yet. Run the implemented preparation step to create actual status records.")

elif page == "Results":
    page_header("Results", "Only verified ligand-preparation artifacts appear here.", "OMNIPHYTO / OUTPUTS")
    panel("Evidence boundary", "This workspace does not report docking scores, rankings, efficacy, ADMET, toxicity, or safety outcomes. A prepared ligand is not a prediction of biological activity.", "NO UNRUN ANALYSIS")
    if not prepared_rows:
        st.info("No validated ligand-preparation outputs exist yet. Results remain empty until an actual PDBQT file is generated and verified.")
        if manifest_rows:
            st.write("Recorded per-compound status and error details:")
            st.dataframe(pd.DataFrame(manifest_rows).fillna(""), hide_index=True, use_container_width=True)
    else:
        st.dataframe(pd.DataFrame(prepared_rows).fillna(""), hide_index=True, use_container_width=True)
        st.caption("These are verified ligand-preparation artifacts only. No docking or binding scores were generated.")

elif page == "Settings":
    page_header("Project settings", "Save your team's actual target context and protocol notes.", "OMNIPHYTO / CONFIGURATION")
    st.info("These settings document inputs. They do not validate scientific suitability or enable docking in this dashboard.")
    with st.form("project_settings"):
        project_name = st.text_input("Project name", settings["project_name"])
        target_name = st.text_input("Target name", settings["target_name"])
        receptor_path = st.text_input("Prepared receptor PDBQT path (optional for ligand preparation)", settings["receptor_path"])
        st.markdown("**Target-specific search box, in angstroms**")
        cols = st.columns(3)
        center = [cols[i].text_input(f"Center {axis}", settings[f"box_center_{axis}"]) for i, axis in enumerate("xyz")]
        cols = st.columns(3)
        size = [cols[i].text_input(f"Size {axis}", settings[f"box_size_{axis}"]) for i, axis in enumerate("xyz")]
        protocol = st.text_area("Protocol / provenance notes", settings["protocol"])
        submitted = st.form_submit_button("Validate and save settings")
    if submitted:
        values = dict(zip(FIELDS, [project_name, target_name, receptor_path, *center, *size, protocol]))
        errors = validate_settings(values)
        if errors:
            for error in errors:
                st.error(error)
        else:
            save_settings(SETTINGS_PATH, values)
            st.success(f"Settings saved to {SETTINGS_PATH.relative_to(ROOT)}")
    panel("For future docking work", "A scientifically prepared receptor PDBQT, justified target-specific box coordinates, a documented approved protocol, and a verified docking implementation would be required. None are fabricated or implied here.", "SCIENTIFIC INPUTS")
